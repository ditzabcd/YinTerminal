package com.yin.term.data.datasource

import android.os.Build
import android.os.SystemClock
import com.yin.term.core.AppDispatchers
import com.yin.term.domain.model.TerminalLog
import com.yin.term.domain.model.TerminalState
import com.yin.term.domain.repository.SettingsRepository
import com.yin.term.domain.repository.TerminalLogRepository
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLDecoder
import java.net.URLEncoder
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Base64
import java.util.Date
import java.util.Locale
import java.util.UUID
import java.util.concurrent.TimeUnit
import kotlin.concurrent.Volatile

class ShellManager(
    private val settingsRepository: SettingsRepository,
    private val terminalLogRepository: TerminalLogRepository,
    private val dispatchers: AppDispatchers
) {
    companion object {
        private val WHITESPACE_REGEX = Regex("\\s+")

        private val morseMap = mapOf(
            'A' to ".-", 'B' to "-...", 'C' to "-.-.", 'D' to "-..", 'E' to ".", 'F' to "..-.",
            'G' to "--.", 'H' to "....", 'I' to "..", 'J' to ".---", 'K' to "-.-", 'L' to ".-..",
            'M' to "--", 'N' to "-.", 'O' to "---", 'P' to ".--.", 'Q' to "--.-", 'R' to ".-.",
            'S' to "...", 'T' to "-", 'U' to "..-", 'V' to "...-", 'W' to ".--", 'X' to "-..-",
            'Y' to "-.--", 'Z' to "--..",
            '0' to "-----", '1' to ".----", '2' to "..---", '3' to "...--", '4' to "....-",
            '5' to ".....", '6' to "-....", '7' to "--...", '8' to "---..", '9' to "----.",
            ' ' to "/"
        )

        private val reverseMorseMap: Map<String, Char> by lazy {
            morseMap.entries.associate { (k, v) -> v to k }
        }
    }

    @Volatile
    private var process: Process? = null

    suspend fun execute(command: String, isRoot: Boolean) {
        withContext(dispatchers.io) {
            var activeProcess: Process? = null
            try {
                val shellCommands = mutableListOf<String>()
                for (rawLine in command.lines()) {
                    val trimmed = rawLine.trim()
                    if (trimmed.isEmpty()) continue
                    if (!executedAsCustomCommand(settingsRepository, terminalLogRepository, trimmed)) {
                        shellCommands.add(rawLine)
                    }
                }

                if (shellCommands.isEmpty()) return@withContext

                activeProcess = ProcessBuilder(if (isRoot) "su" else "/system/bin/sh")
                    .redirectErrorStream(true)
                    .start()
                process = activeProcess

                val writerJob = launch {
                    runCatching {
                        activeProcess.outputStream.bufferedWriter().use { writer ->
                            for (cmd in shellCommands) {
                                writer.write(cmd)
                                writer.newLine()
                            }
                            writer.write("exit")
                            writer.newLine()
                            writer.flush()
                        }
                    }
                }

                activeProcess.inputStream.bufferedReader().use { reader ->
                    var line: String?
                    while (reader.readLine().also { line = it } != null) {
                        terminalLogRepository.addLog(TerminalLog(TerminalState.Success, "$line\n"))
                    }
                }

                writerJob.join()
                activeProcess.waitFor()
            } catch (e: Exception) {
                terminalLogRepository.addLog(
                    TerminalLog(TerminalState.Error, "${e.message ?: "Unknown Error"}\n")
                )
            } finally {
                activeProcess?.let { proc ->
                    runCatching { proc.inputStream.close() }
                    runCatching { proc.outputStream.close() }
                    runCatching { proc.errorStream.close() }
                    proc.destroyForcibly()
                }
                process = null
            }
        }
    }

    suspend fun cancel() {
        withContext(dispatchers.io) {
            val current = process
            if (current == null) {
                terminalLogRepository.addLog(
                    TerminalLog(TerminalState.Error, "There is no active process\n")
                )
                return@withContext
            }

            val pid = getPid(current)
            if (pid != -1) {
                runCatching { Runtime.getRuntime().exec(arrayOf("pkill", "-P", pid.toString())) }
            }
            current.destroy()
            if (!current.waitFor(1000, TimeUnit.MILLISECONDS)) {
                current.destroyForcibly()
                current.waitFor()
            }
            runCatching { current.inputStream.close() }
            runCatching { current.outputStream.close() }
            runCatching { current.errorStream.close() }
            terminalLogRepository.addLog(
                TerminalLog(TerminalState.Error, "Process terminated by user\n")
            )
            process = null
        }
    }

    private fun getPid(proc: Process): Int {
        return try {
            val field = proc.javaClass.getDeclaredField("pid")
            field.isAccessible = true
            field.getInt(proc)
        } catch (_: Exception) {
            -1
        }
    }

    private suspend fun executedAsCustomCommand(
        settingsRepository: SettingsRepository,
        terminalLogRepository: TerminalLogRepository,
        command: String
    ): Boolean {
        val tokens = command.split(WHITESPACE_REGEX)
        if (tokens.isEmpty() || tokens[0].isEmpty()) return false

        when (val baseCommand = tokens[0].lowercase(Locale.ROOT)) {
            "help" -> {
                val helpText = """
                    
                ===== SYSTEM =====
                
                • help - Show this command list.
                • about - Display app and developer info.
                • clear / cls - Clear all terminal logs.
                • sysinfo - Hardware & OS details.
                • uptime - Show system boot duration.
                • datetime - Display current date & time.
                • sudo [cmd] - Simulate root privilege command.
                  
                ===== CUSTOMIZE =====
                
                • font [size] - Set terminal font size (5-25).
                • font def - Reset font size to default (10).
                • color1 [r g b] / def - Normal text RGB color.
                • color2 [r g b] / def - Error text RGB color.
                • color3 [r g b] / def - Info text RGB color.
                  
                ===== TEXT =====
                
                • random [a] [b] - Random number between a and b.
                • uuid - Generate a random UUID v4 string.
                • length [text] - Count characters in a string.
                • case [up/low] [text] - Convert upper/lowercase.
                • wordcount [text] - Count words in text.
                • sort [w1] [w2] ... - Sort words alphabetically.
                • shuffle [w1] [w2] ... - Shuffle list of words.
                • reverse [text] - Reverse character order.
                • palindrome [text] - Check palindrome.
                • regex [pattern] [text] - Find regex matches.

                ===== CRYPTO & ENCODE =====
                
                • base64 [enc/dec] [text] - Base64 encode/decode.
                • hash [algo] [text] - Generate md5, sha1, sha256.
                • url [enc/dec] [text] - URL encode/decode.
                • rot13 [text] - Apply ROT13 cipher.
                • morse [enc/dec] [text] - Morse code encode/decode.
                • binary [enc/dec] [text] - Text to/from binary.
                • hex [enc/dec] [text] - Text to/from hex string.
                • ascii [single char] - Decimal ASCII code.

                ===== DEV TOOLS =====
                
                • pass [length] - Generate random password (4-128).
                • json [validate/format] [txt] - Validate/format JSON.

                ===== PYTHON ENGINE =====
                
                • py - First line trigger for pure Python mode.
                • pip install [package] - Install Pure Python wheel.
                • pip uninstall [package] - Remove installed package.
                • pip list - List user-installed Python packages.
                • python [file_path] [args...] - Run local .py script.
                """.trimIndent()
                terminalLogRepository.addLog(TerminalLog(TerminalState.Success, "$helpText\n"))
            }

            "about" -> {
                val aboutText = """
                    
                __   ___     _____                    
                \ \ / (_)_ _|_   _|__ _ _ _ __        
                 \ V /| | ' \ | |/ -_) '_| '  \       
                  |_| |_|_||_||_|\___|_| |_|_|_|      
                                                      
                YinTerm v1.0 - Lightweight Android Shell & Python 3.13
                Based on DTerminal (GPL-3.0) by DeDeadend
                """.trimIndent()
                terminalLogRepository.addLog(TerminalLog(TerminalState.Success, "$aboutText\n"))
            }

            "color", "color1", "color2", "color3" -> {
                val type = if (baseCommand == "color") 1 else baseCommand.last().digitToInt()
                handleColorCommand(tokens, type, settingsRepository, terminalLogRepository)
            }

            "font" -> {
                if (tokens.size == 2) {
                    if (tokens[1] == "def") {
                        settingsRepository.setLogFontSize(10)
                        terminalLogRepository.addLog(
                            TerminalLog(TerminalState.Success, "Font size set to default (10).\n")
                        )
                    } else {
                        val fontSize = tokens[1].toIntOrNull()
                        if (fontSize != null && fontSize in 5..25) {
                            settingsRepository.setLogFontSize(fontSize)
                            terminalLogRepository.addLog(
                                TerminalLog(TerminalState.Success, "Font size set successfully.\n")
                            )
                        } else {
                            terminalLogRepository.addLog(
                                TerminalLog(TerminalState.Error, "Invalid size (5-25).\n")
                            )
                        }
                    }
                } else {
                    terminalLogRepository.addLog(
                        TerminalLog(TerminalState.Error, "Usage: font [size] or [def]\n")
                    )
                }
            }

            "random" -> {
                if (tokens.size == 3) {
                    val num1 = tokens[1].toIntOrNull()
                    val num2 = tokens[2].toIntOrNull()
                    if (num1 != null && num2 != null) {
                        val min = minOf(num1, num2)
                        val max = maxOf(num1, num2)
                        terminalLogRepository.addLog(
                            TerminalLog(TerminalState.Success, "${(min..max).random()}\n")
                        )
                    } else {
                        terminalLogRepository.addLog(
                            TerminalLog(TerminalState.Error, "Enter valid numbers.\n")
                        )
                    }
                } else {
                    terminalLogRepository.addLog(
                        TerminalLog(TerminalState.Error, "Usage: random [a] [b]\n")
                    )
                }
            }

            "clear", "cls" -> terminalLogRepository.clearLogs()

            "sysinfo" -> {
                val primaryAbi = Build.SUPPORTED_ABIS.firstOrNull() ?: "Unknown"
                val allAbis = Build.SUPPORTED_ABIS.joinToString(", ")
                val cores = Runtime.getRuntime().availableProcessors()
                val maxVmMem = Runtime.getRuntime().maxMemory() / (1024 * 1024)
                val buildDate = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())
                    .format(Date(Build.TIME))

                val info = """
                [ HARDWARE ]
                • Model: ${Build.BRAND} ${Build.MODEL}
                • Maker: ${Build.MANUFACTURER}
                • Board: ${Build.BOARD}
                • Device: ${Build.DEVICE}
                • Product: ${Build.PRODUCT}
                • Hardware: ${Build.HARDWARE}
                • Bootloader: ${Build.BOOTLOADER}
                
                [ CPU & MEMORY ]
                • CPU Cores: $cores cores
                • Architecture: ${System.getProperty("os.arch")}
                • Primary ABI: $primaryAbi
                • Supported ABIs: $allAbis
                • JVM Max Memory: ${maxVmMem}MB
                
                [ OS & BUILD ]
                • Android OS: ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})
                • Security Patch: ${Build.VERSION.SECURITY_PATCH}
                • Build ID: ${Build.ID}
                • Build Display: ${Build.DISPLAY}
                • Build Type/Tags: ${Build.TYPE} / ${Build.TAGS}
                • Kernel Version: ${System.getProperty("os.version")}
                • Build Date: $buildDate
                • Fingerprint:
                  ${Build.FINGERPRINT}
                
                [ STATUS ]
                • Uptime: ${getSystemUptime()}
                """.trimIndent()
                terminalLogRepository.addLog(TerminalLog(TerminalState.Success, "$info\n"))
            }

            "uptime" -> {
                terminalLogRepository.addLog(
                    TerminalLog(TerminalState.Success, "Uptime: ${getSystemUptime()}\n")
                )
            }

            "datetime" -> {
                val current = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
                    .format(Date())
                terminalLogRepository.addLog(TerminalLog(TerminalState.Success, "$current\n"))
            }

            "length" -> {
                if (tokens.size >= 2) {
                    val text = tokens.drop(1).joinToString(" ")
                    terminalLogRepository.addLog(
                        TerminalLog(TerminalState.Success, "Length: ${text.length}\n")
                    )
                } else {
                    terminalLogRepository.addLog(
                        TerminalLog(TerminalState.Error, "Usage: length [text]\n")
                    )
                }
            }

            "case" -> {
                if (tokens.size >= 3) {
                    val action = tokens[1].lowercase(Locale.ROOT)
                    val text = tokens.drop(2).joinToString(" ")
                    val result = if (action == "up" || action == "upper") {
                        text.uppercase(Locale.getDefault())
                    } else {
                        text.lowercase(Locale.getDefault())
                    }
                    terminalLogRepository.addLog(TerminalLog(TerminalState.Success, "$result\n"))
                } else {
                    terminalLogRepository.addLog(
                        TerminalLog(TerminalState.Error, "Usage: case [up/low] [text]\n")
                    )
                }
            }

            "url" -> {
                if (tokens.size >= 3) {
                    val action = tokens[1].lowercase(Locale.ROOT)
                    val text = tokens.drop(2).joinToString(" ")
                    try {
                        val result = if (action == "enc" || action == "encode") {
                            URLEncoder.encode(text, "UTF-8")
                        } else {
                            URLDecoder.decode(text, "UTF-8")
                        }
                        terminalLogRepository.addLog(TerminalLog(TerminalState.Success, "$result\n"))
                    } catch (_: Exception) {
                        terminalLogRepository.addLog(
                            TerminalLog(TerminalState.Error, "URL operation failed.\n")
                        )
                    }
                } else {
                    terminalLogRepository.addLog(
                        TerminalLog(TerminalState.Error, "Usage: url [enc/dec] [text]\n")
                    )
                }
            }

            "base64" -> {
                if (tokens.size >= 3) {
                    val action = tokens[1].lowercase(Locale.ROOT)
                    val text = tokens.drop(2).joinToString(" ")
                    when (action) {
                        "enc", "encode" -> {
                            val encoded = Base64.getEncoder().encodeToString(text.toByteArray())
                            terminalLogRepository.addLog(TerminalLog(TerminalState.Success, "$encoded\n"))
                        }
                        "dec", "decode" -> {
                            try {
                                val decoded = String(Base64.getDecoder().decode(text))
                                terminalLogRepository.addLog(TerminalLog(TerminalState.Success, "$decoded\n"))
                            } catch (_: Exception) {
                                terminalLogRepository.addLog(
                                    TerminalLog(TerminalState.Error, "Invalid Base64.\n")
                                )
                            }
                        }
                        else -> terminalLogRepository.addLog(
                            TerminalLog(TerminalState.Error, "Usage: base64 [enc/dec] [text]\n")
                        )
                    }
                } else {
                    terminalLogRepository.addLog(
                        TerminalLog(TerminalState.Error, "Usage: base64 [enc/dec] [text]\n")
                    )
                }
            }

            "hash" -> {
                if (tokens.size >= 3) {
                    val targetAlgo = when (tokens[1].lowercase(Locale.ROOT)) {
                        "md5" -> "MD5"
                        "sha1" -> "SHA-1"
                        "sha256" -> "SHA-256"
                        else -> null
                    }
                    val text = tokens.drop(2).joinToString(" ")
                    if (targetAlgo != null) {
                        try {
                            val digest = MessageDigest.getInstance(targetAlgo)
                            val hashString = digest.digest(text.toByteArray())
                                .joinToString("") { "%02x".format(it) }
                            terminalLogRepository.addLog(TerminalLog(TerminalState.Success, "$hashString\n"))
                        } catch (_: Exception) {
                            terminalLogRepository.addLog(
                                TerminalLog(TerminalState.Error, "Hash failed.\n")
                            )
                        }
                    } else {
                        terminalLogRepository.addLog(
                            TerminalLog(TerminalState.Error, "Use: md5, sha1, sha256\n")
                        )
                    }
                } else {
                    terminalLogRepository.addLog(
                        TerminalLog(TerminalState.Error, "Usage: hash [algo] [text]\n")
                    )
                }
            }

            "uuid" -> {
                terminalLogRepository.addLog(
                    TerminalLog(TerminalState.Success, "${UUID.randomUUID()}\n")
                )
            }

            "sudo" -> {
                terminalLogRepository.addLog(
                    TerminalLog(
                        TerminalState.Success,
                        "Switch to Root mode or use 'su' instead.\n"
                    )
                )
            }

            "rot13" -> {
                if (tokens.size >= 2) {
                    val text = tokens.drop(1).joinToString(" ")
                    val result = text.map { c ->
                        when {
                            c in 'A'..'Z' -> 'A' + (c - 'A' + 13) % 26
                            c in 'a'..'z' -> 'a' + (c - 'a' + 13) % 26
                            else -> c
                        }
                    }.joinToString("")
                    terminalLogRepository.addLog(TerminalLog(TerminalState.Success, "$result\n"))
                } else {
                    terminalLogRepository.addLog(
                        TerminalLog(TerminalState.Error, "Usage: rot13 [text]\n")
                    )
                }
            }

            "reverse" -> {
                if (tokens.size >= 2) {
                    val text = tokens.drop(1).joinToString(" ")
                    terminalLogRepository.addLog(
                        TerminalLog(TerminalState.Success, "${text.reversed()}\n")
                    )
                } else {
                    terminalLogRepository.addLog(
                        TerminalLog(TerminalState.Error, "Usage: reverse [text]\n")
                    )
                }
            }

            "palindrome" -> {
                if (tokens.size >= 2) {
                    val text = tokens.drop(1).joinToString("")
                    val normalized = text.lowercase(Locale.ROOT).filter { it.isLetterOrDigit() }
                    val isPalindrome = normalized == normalized.reversed()
                    terminalLogRepository.addLog(
                        TerminalLog(
                            TerminalState.Success,
                            if (isPalindrome) "Yes, it's a palindrome.\n" else "No, it's not a palindrome.\n"
                        )
                    )
                } else {
                    terminalLogRepository.addLog(
                        TerminalLog(TerminalState.Error, "Usage: palindrome [text]\n")
                    )
                }
            }

            "morse" -> {
                if (tokens.size >= 3) {
                    val action = tokens[1].lowercase(Locale.ROOT)
                    val text = tokens.drop(2).joinToString(" ")
                    when (action) {
                        "enc", "encode" -> {
                            val result = text.uppercase(Locale.ROOT)
                                .joinToString(" ") { c -> morseMap[c] ?: c.toString() }
                            terminalLogRepository.addLog(TerminalLog(TerminalState.Success, "$result\n"))
                        }
                        "dec", "decode" -> {
                            val result = text.trim().split(' ').joinToString("") { code ->
                                reverseMorseMap[code]?.toString() ?: code
                            }
                            terminalLogRepository.addLog(TerminalLog(TerminalState.Success, "$result\n"))
                        }
                        else -> terminalLogRepository.addLog(
                            TerminalLog(TerminalState.Error, "Usage: morse [enc/dec] [text]\n")
                        )
                    }
                } else {
                    terminalLogRepository.addLog(
                        TerminalLog(TerminalState.Error, "Usage: morse [enc/dec] [text]\n")
                    )
                }
            }

            "binary" -> {
                if (tokens.size >= 3) {
                    val action = tokens[1].lowercase(Locale.ROOT)
                    val text = tokens.drop(2).joinToString(" ")
                    when (action) {
                        "enc", "encode" -> {
                            val result = text.toByteArray().joinToString(" ") {
                                Integer.toBinaryString(it.toInt() and 0xFF).padStart(8, '0')
                            }
                            terminalLogRepository.addLog(TerminalLog(TerminalState.Success, "$result\n"))
                        }
                        "dec", "decode" -> {
                            try {
                                val bytes = text.trim().split(' ')
                                    .map { it.toInt(2).toByte() }.toByteArray()
                                terminalLogRepository.addLog(
                                    TerminalLog(TerminalState.Success, "${String(bytes)}\n")
                                )
                            } catch (_: Exception) {
                                terminalLogRepository.addLog(
                                    TerminalLog(TerminalState.Error, "Invalid binary.\n")
                                )
                            }
                        }
                        else -> terminalLogRepository.addLog(
                            TerminalLog(TerminalState.Error, "Usage: binary [enc/dec] [text]\n")
                        )
                    }
                } else {
                    terminalLogRepository.addLog(
                        TerminalLog(TerminalState.Error, "Usage: binary [enc/dec] [text]\n")
                    )
                }
            }

            "hex" -> {
                if (tokens.size >= 3) {
                    val action = tokens[1].lowercase(Locale.ROOT)
                    val text = tokens.drop(2).joinToString(" ")
                    when (action) {
                        "enc", "encode" -> {
                            val result = text.toByteArray().joinToString("") { "%02x".format(it) }
                            terminalLogRepository.addLog(TerminalLog(TerminalState.Success, "$result\n"))
                        }
                        "dec", "decode" -> {
                            try {
                                val clean = text.trim().replace(" ", "")
                                val bytes = clean.chunked(2)
                                    .map { it.toInt(16).toByte() }.toByteArray()
                                terminalLogRepository.addLog(
                                    TerminalLog(TerminalState.Success, "${String(bytes)}\n")
                                )
                            } catch (_: Exception) {
                                terminalLogRepository.addLog(
                                    TerminalLog(TerminalState.Error, "Invalid hex.\n")
                                )
                            }
                        }
                        else -> terminalLogRepository.addLog(
                            TerminalLog(TerminalState.Error, "Usage: hex [enc/dec] [text]\n")
                        )
                    }
                } else {
                    terminalLogRepository.addLog(
                        TerminalLog(TerminalState.Error, "Usage: hex [enc/dec] [text]\n")
                    )
                }
            }

            "ascii" -> {
                if (tokens.size == 2 && tokens[1].length == 1) {
                    terminalLogRepository.addLog(
                        TerminalLog(TerminalState.Success, "${tokens[1][0].code}\n")
                    )
                } else {
                    terminalLogRepository.addLog(
                        TerminalLog(TerminalState.Error, "Usage: ascii [single char]\n")
                    )
                }
            }

            "wordcount" -> {
                if (tokens.size >= 2) {
                    terminalLogRepository.addLog(
                        TerminalLog(TerminalState.Success, "Words: ${tokens.drop(1).size}\n")
                    )
                } else {
                    terminalLogRepository.addLog(
                        TerminalLog(TerminalState.Error, "Usage: wordcount [text]\n")
                    )
                }
            }

            "sort" -> {
                if (tokens.size >= 2) {
                    terminalLogRepository.addLog(
                        TerminalLog(TerminalState.Success, "${tokens.drop(1).sorted().joinToString(" ")}\n")
                    )
                } else {
                    terminalLogRepository.addLog(
                        TerminalLog(TerminalState.Error, "Usage: sort [word1] [word2] ...\n")
                    )
                }
            }

            "shuffle" -> {
                if (tokens.size >= 2) {
                    terminalLogRepository.addLog(
                        TerminalLog(TerminalState.Success, "${tokens.drop(1).shuffled().joinToString(" ")}\n")
                    )
                } else {
                    terminalLogRepository.addLog(
                        TerminalLog(TerminalState.Error, "Usage: shuffle [word1] [word2] ...\n")
                    )
                }
            }

            "pass" -> {
                if (tokens.size == 2) {
                    val length = tokens[1].toIntOrNull()
                    if (length != null && length in 4..128) {
                        val chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*"
                        val result = (1..length).map { chars.random() }.joinToString("")
                        terminalLogRepository.addLog(TerminalLog(TerminalState.Success, "$result\n"))
                    } else {
                        terminalLogRepository.addLog(
                            TerminalLog(TerminalState.Error, "Length must be 4-128.\n")
                        )
                    }
                } else {
                    terminalLogRepository.addLog(
                        TerminalLog(TerminalState.Error, "Usage: pass [length]\n")
                    )
                }
            }

            "json" -> {
                if (tokens.size >= 3) {
                    val action = tokens[1].lowercase(Locale.ROOT)
                    val text = tokens.drop(2).joinToString(" ")
                    try {
                        val parsed: Any = try {
                            JSONObject(text)
                        } catch (_: Exception) {
                            JSONArray(text)
                        }
                        when (action) {
                            "validate" -> terminalLogRepository.addLog(
                                TerminalLog(TerminalState.Success, "Valid JSON.\n")
                            )
                            "format" -> {
                                val formatted = when (parsed) {
                                    is JSONObject -> parsed.toString(2)
                                    is JSONArray -> parsed.toString(2)
                                    else -> text
                                }
                                terminalLogRepository.addLog(TerminalLog(TerminalState.Success, "$formatted\n"))
                            }
                            else -> terminalLogRepository.addLog(
                                TerminalLog(TerminalState.Error, "Usage: json [validate/format] [text]\n")
                            )
                        }
                    } catch (_: Exception) {
                        terminalLogRepository.addLog(
                            TerminalLog(TerminalState.Error, "Invalid JSON.\n")
                        )
                    }
                } else {
                    terminalLogRepository.addLog(
                        TerminalLog(TerminalState.Error, "Usage: json [validate/format] [text]\n")
                    )
                }
            }

            "regex" -> {
                if (tokens.size >= 3) {
                    val pattern = tokens[1]
                    val text = tokens.drop(2).joinToString(" ")
                    try {
                        val matches = Regex(pattern).findAll(text).map { it.value }.toList()
                        val result = if (matches.isEmpty()) "No match." else "Matches: ${matches.joinToString(", ")}"
                        terminalLogRepository.addLog(TerminalLog(TerminalState.Success, "$result\n"))
                    } catch (_: Exception) {
                        terminalLogRepository.addLog(
                            TerminalLog(TerminalState.Error, "Invalid regex pattern.\n")
                        )
                    }
                } else {
                    terminalLogRepository.addLog(
                        TerminalLog(TerminalState.Error, "Usage: regex [pattern] [text]\n")
                    )
                }
            }

            else -> return false
        }
        return true
    }

    private fun getSystemUptime(): String {
        val upTime = SystemClock.elapsedRealtime()
        val hours = upTime / 3600000
        val minutes = (upTime / 60000) % 60
        val seconds = (upTime / 1000) % 60
        return String.format(Locale.getDefault(), "%02d:%02d:%02d", hours, minutes, seconds)
    }

    private suspend fun handleColorCommand(
        tokens: List<String>,
        colorType: Int,
        settingsRepository: SettingsRepository,
        terminalLogRepository: TerminalLogRepository
    ) {
        val usage = "Usage: color$colorType [r g b] or [def]\n"
        when (tokens.size) {
            2 -> {
                if (tokens[1] == "def") {
                    updateRepositoryColor(settingsRepository, colorType, -1, -1, -1)
                    terminalLogRepository.addLog(
                        TerminalLog(TerminalState.Success, "Color $colorType reset to default.\n")
                    )
                } else {
                    terminalLogRepository.addLog(TerminalLog(TerminalState.Error, usage))
                }
            }
            4 -> {
                val r = tokens[1].toIntOrNull()
                val g = tokens[2].toIntOrNull()
                val b = tokens[3].toIntOrNull()
                if (r != null && g != null && b != null && r in 0..255 && g in 0..255 && b in 0..255) {
                    updateRepositoryColor(settingsRepository, colorType, r, g, b)
                    terminalLogRepository.addLog(
                        TerminalLog(TerminalState.Success, "Color $colorType applied.\n")
                    )
                } else {
                    terminalLogRepository.addLog(
                        TerminalLog(TerminalState.Error, "Values must be 0-255.\n")
                    )
                }
            }
            else -> terminalLogRepository.addLog(TerminalLog(TerminalState.Error, usage))
        }
    }

    private suspend fun updateRepositoryColor(
        repo: SettingsRepository,
        type: Int,
        r: Int,
        g: Int,
        b: Int
    ) {
        when (type) {
            1 -> repo.setLogSuccessFontColor(r, g, b)
            2 -> repo.setLogErrorFontColor(r, g, b)
            3 -> repo.setLogInfoFontColor(r, g, b)
        }
    }
}