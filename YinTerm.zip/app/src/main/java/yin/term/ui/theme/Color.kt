package com.yin.term.ui.theme

import androidx.compose.ui.graphics.Color

val InfoTextColor = Color(0xFF38BDF8)
val ErrorTextColor = Color(0xFFEF4444)

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650A4)
val PurpleGrey40 = Color(0xFF625B71)
val Pink40 = Color(0xFF7D5260)