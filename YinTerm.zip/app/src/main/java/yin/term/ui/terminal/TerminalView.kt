package com.yin.term.ui.terminal

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Environment
import android.provider.Settings
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.DpOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.net.toUri
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.yin.term.R
import com.yin.term.core.BaseTopBar
import com.yin.term.core.YinIcons
import com.yin.term.domain.model.TerminalState
import kotlinx.coroutines.flow.Flow

@SuppressLint("ConfigurationScreenWidthHeight")
@Composable
fun Terminal(
    viewModel: TerminalViewModel = viewModel(factory = TerminalViewModel.Factory),
    terminalCommandChannel: Flow<String>
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    val configuration = LocalConfiguration.current
    val maxHeight = configuration.screenHeightDp.dp / 3

    LaunchedEffect(viewModel) {
        terminalCommandChannel.collect { command ->
            viewModel.onEvent(TerminalUiEvent.OnCommandChange(command))
        }
    }

    val scrollState = rememberScrollState()
    LaunchedEffect(uiState.terminalLogText) {
        if (scrollState.maxValue > 0) {
            scrollState.animateScrollTo(scrollState.maxValue)
        }
    }

    Scaffold(
        topBar = { TerminalTopBar(viewModel, uiState) }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .weight(1f),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceContainer
                )
            ) {
                SelectionContainer {
                    Text(
                        modifier = Modifier
                            .fillMaxWidth()
                            .verticalScroll(scrollState)
                            .padding(12.dp),
                        text = uiState.terminalLogText,
                        fontSize = uiState.settings.logFontSize.sp,
                        fontFamily = FontFamily.Monospace,
                        lineHeight = (uiState.settings.logFontSize + 5).sp,
                        textAlign = TextAlign.Left,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .animateContentSize()
                    .heightIn(max = maxHeight)
                    .padding(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceContainer
                ),
                elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp),
                    verticalAlignment = Alignment.Bottom
                ) {
                    TextField(
                        modifier = Modifier.weight(1f),
                        value = uiState.command,
                        onValueChange = { viewModel.onEvent(TerminalUiEvent.OnCommandChange(it)) },
                        placeholder = {
                            Text(
                                text = "Enter ${if (uiState.isRoot) "#" else "$"} commands..."
                            )
                        },
                        maxLines = Int.MAX_VALUE,
                        colors = TextFieldDefaults.colors(
                            unfocusedContainerColor = MaterialTheme.colorScheme.surfaceContainer,
                            focusedContainerColor = MaterialTheme.colorScheme.surfaceContainer
                        )
                    )
                    Box(
                        modifier = Modifier
                            .padding(8.dp)
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primary)
                            .clickable(enabled = uiState.executionState != TerminalState.Running) {
                                viewModel.onEvent(TerminalUiEvent.Execute)
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        if (uiState.executionState == TerminalState.Running) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(24.dp),
                                color = MaterialTheme.colorScheme.onPrimary,
                                strokeWidth = 2.dp
                            )
                        } else {
                            Icon(
                                imageVector = YinIcons.PlayArrow,
                                contentDescription = "Run",
                                tint = MaterialTheme.colorScheme.onPrimary
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TerminalTopBar(
    viewModel: TerminalViewModel,
    uiState: TerminalUiState
) {
    val uriHandler = LocalUriHandler.current
    val context = LocalContext.current

    BaseTopBar(actions = {
        Box(modifier = Modifier.padding(top = 24.dp)) {
            IconButton(onClick = { viewModel.onEvent(TerminalUiEvent.ToggleToolsMenu(true)) }) {
                Icon(
                    imageVector = YinIcons.MoreVert,
                    contentDescription = "Tools",
                    tint = MaterialTheme.colorScheme.onSurface
                )
            }
            DropdownMenu(
                expanded = uiState.isToolsMenuOpen,
                onDismissRequest = { viewModel.onEvent(TerminalUiEvent.ToggleToolsMenu(false)) },
                offset = DpOffset(0.dp, 16.dp)
            ) {
                DropdownMenuItem(
                    text = { Text("GitHub (Upstream)") },
                    onClick = {
                        viewModel.onEvent(TerminalUiEvent.ToggleToolsMenu(false))
                        uriHandler.openUri("https://github.com/dedeadend/DTerminal")
                    },
                    leadingIcon = {
                        Icon(
                            painter = painterResource(R.drawable.ic_github),
                            contentDescription = "GitHub",
                            tint = MaterialTheme.colorScheme.onSurface
                        )
                    }
                )
                DropdownMenuItem(
                    text = { Text("Clear output") },
                    onClick = {
                        viewModel.onEvent(TerminalUiEvent.ToggleToolsMenu(false))
                        viewModel.onEvent(TerminalUiEvent.ClearOutput)
                    },
                    leadingIcon = {
                        Icon(
                            imageVector = YinIcons.ClearAll,
                            contentDescription = "Clear",
                            tint = MaterialTheme.colorScheme.onSurface
                        )
                    }
                )
                DropdownMenuItem(
                    text = { Text("Terminate process") },
                    onClick = {
                        viewModel.onEvent(TerminalUiEvent.ToggleToolsMenu(false))
                        viewModel.onEvent(TerminalUiEvent.Terminate)
                    },
                    leadingIcon = {
                        Icon(
                            imageVector = YinIcons.Clear,
                            contentDescription = "Terminate",
                            tint = MaterialTheme.colorScheme.onSurface
                        )
                    }
                )
                DropdownMenuItem(
                    text = { Text(if (uiState.isRoot) "Switch to Shell mode" else "Switch to Root mode") },
                    onClick = {
                        viewModel.onEvent(TerminalUiEvent.ToggleToolsMenu(false))
                        viewModel.onEvent(TerminalUiEvent.ToggleRoot)
                    },
                    leadingIcon = {
                        Icon(
                            imageVector = YinIcons.Grass,
                            contentDescription = "Root",
                            tint = MaterialTheme.colorScheme.onSurface
                        )
                    }
                )
                if (!Environment.isExternalStorageManager()) {
                    DropdownMenuItem(
                        text = { Text("Storage Permission") },
                        onClick = {
                            viewModel.onEvent(TerminalUiEvent.ToggleToolsMenu(false))
                            val intent = Intent(
                                Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION
                            ).apply {
                                data = "package:${context.packageName}".toUri()
                            }
                            context.startActivity(intent)
                        },
                        leadingIcon = {
                            Icon(
                                imageVector = YinIcons.Storage,
                                contentDescription = "Storage Permission",
                                tint = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    )
                }
            }
        }
    })
}