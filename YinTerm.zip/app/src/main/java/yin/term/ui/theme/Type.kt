package com.yin.term.ui.theme

import androidx.compose.material3.Typography

val Typography = Typography()